﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;
using Tollbooth.Models;

namespace Tollbooth.Controllers
{
    public class HomeController : Controller
    {
        [Authorize]
        public ActionResult Index()
        {
            
            return View();
        }

        [HttpPost]
        public ActionResult Page2(TollPay obj)
        {
            //try
            //{
            //    if (obj.ToString() == "null")
            //    {
            //        RedirectToAction("Index","Home");
            //    }
            //}
            //catch (Exception ex)
            //{
            //    RedirectToAction("Index");
            //}
            TempData["obj"]=obj;
            return View(obj);
        }

       
       
        public ActionResult AddToll()
        {
            TollPay obj1 = (TollPay)TempData["obj"];
            //TempData.Keep("obj");
            //try
            //{
            //    if (obj1.ToString() == "null")
            //    {
            //        RedirectToAction("Index");
            //    }
            //}
            //catch(Exception ex)
            //{
            //    RedirectToAction("Index","Home");
            //}
            switch (obj1.VehicleType)
            {
                case "Auto, Motorcycle":
                    obj1.Amount = (decimal)5.00; break;

                case "Single unit trucks, Buses":
                    obj1.Amount = (decimal)10.00; break;

                case "Medium Trucks":
                    obj1.Amount = (decimal)15.00; break;
                case "Large Trucks":
                    obj1.Amount = (decimal)20.00; break;

                
            }
            ViewBag.Amount = obj1.Amount;
            ViewBag.PlateState = obj1.PlateState;
            ViewBag.VehicleType = obj1.VehicleType;
            ViewBag.LicencePlate = obj1.LicencePlate;
            TempData["price"] = obj1.Amount;
            return View();
        }

        public ActionResult About()
        {
            ViewBag.Message = "This is a Toll based simple application";

            return View();
        }

        public ActionResult Payment()
        {
            ViewBag.Amount1 = TempData["price"];

            return View();
        }

        public ActionResult PaymentSuccessfull()
        {
            

            return View();
        }

        public ActionResult Contact()
        {
            ViewBag.Message = "Your contact page.";

            return View();
        }
    }
}