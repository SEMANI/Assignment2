﻿using Microsoft.Owin;
using Owin;

[assembly: OwinStartupAttribute(typeof(Tollbooth.Startup))]
namespace Tollbooth
{
    public partial class Startup
    {
        public void Configuration(IAppBuilder app)
        {
            ConfigureAuth(app);
        }
    }
}
